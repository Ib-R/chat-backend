A Pen created at CodePen.io. You can find this one at http://codepen.io/searleb/pen/pvQaJB.

 A text readable clock.
Availble here:
https://chrome.google.com/webstore/detail/text-clock/caacmmeopdailkdlgkimndodjipilaha