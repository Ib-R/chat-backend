A Pen created at CodePen.io. You can find this one at http://codepen.io/towc/pen/QjOrVg.

 move your mouse over the canvas!
If you're experience perf issues, try reducing the number of particles on line 7